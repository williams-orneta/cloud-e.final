USE pollu_db;

-- =========================================================
-- CONSULTAS DE VALIDACIÓN
-- =========================================================

SELECT 'categoria' AS tabla, COUNT(*) AS total FROM categoria
UNION ALL SELECT 'tipo_producto', COUNT(*) FROM tipo_producto
UNION ALL SELECT 'tipo_documento', COUNT(*) FROM tipo_documento
UNION ALL SELECT 'rol', COUNT(*) FROM rol
UNION ALL SELECT 'distrito', COUNT(*) FROM distrito
UNION ALL SELECT 'medio_pago', COUNT(*) FROM medio_pago
UNION ALL SELECT 'estado_venta', COUNT(*) FROM estado_venta
UNION ALL SELECT 'estado_reserva', COUNT(*) FROM estado_reserva
UNION ALL SELECT 'tipo_venta', COUNT(*) FROM tipo_venta
UNION ALL SELECT 'sucursal', COUNT(*) FROM sucursal
UNION ALL SELECT 'cliente', COUNT(*) FROM cliente
UNION ALL SELECT 'usuario', COUNT(*) FROM usuario
UNION ALL SELECT 'mesa', COUNT(*) FROM mesa
UNION ALL SELECT 'producto', COUNT(*) FROM producto
UNION ALL SELECT 'inventario_producto', COUNT(*) FROM inventario_producto
UNION ALL SELECT 'reserva', COUNT(*) FROM reserva
UNION ALL SELECT 'venta', COUNT(*) FROM venta
UNION ALL SELECT 'detalle_venta', COUNT(*) FROM detalle_venta
UNION ALL SELECT 'comprobante', COUNT(*) FROM comprobante;

SELECT 
    v.id_venta,
    v.fecha_venta,
    CONCAT(c.nombres, ' ', c.apellidos) AS cliente,
    s.nombre AS sucursal,
    tv.nombre AS tipo_venta,
    mp.nombre AS medio_pago,
    ev.nombre AS estado_venta,
    v.total
FROM venta v
INNER JOIN cliente c ON v.id_cliente = c.id_cliente
INNER JOIN sucursal s ON v.id_sucursal = s.id_sucursal
INNER JOIN tipo_venta tv ON v.id_tipo_venta = tv.id_tipo_venta
INNER JOIN medio_pago mp ON v.id_medio_pago = mp.id_medio_pago
INNER JOIN estado_venta ev ON v.id_estado_venta = ev.id_estado_venta;

SELECT
    r.id_reserva,
    r.fecha_reserva,
    r.hora_reserva,
    CONCAT(c.nombres, ' ', c.apellidos) AS cliente,
    m.numero AS mesa,
    er.nombre AS estado_reserva
FROM reserva r
INNER JOIN cliente c ON r.id_cliente = c.id_cliente
INNER JOIN mesa m ON r.id_mesa = m.id_mesa
INNER JOIN estado_reserva er ON r.id_estado_reserva = er.id_estado_reserva;
