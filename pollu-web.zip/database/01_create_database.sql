-- =========================================================
-- BASE DE DATOS: P'OLLU S.A.C.
-- Versión: v1 - Modelo físico para pollería
-- Motor sugerido: MySQL 8+
-- =========================================================

DROP DATABASE IF EXISTS pollu_db;

CREATE DATABASE pollu_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE pollu_db;