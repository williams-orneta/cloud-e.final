USE pollu_db;

-- =========================================================
-- DATA DE PRUEBA
-- =========================================================

INSERT INTO categoria (nombre, descripcion, estado) VALUES
('Pollos a la brasa', 'Pollos enteros, medios y cuartos de pollo', 1),
('Combos familiares', 'Promociones para grupos y familias', 1),
('Guarniciones', 'Papas, ensaladas, arroz y complementos', 1),
('Bebidas', 'Bebidas personales y familiares', 1),
('Entradas', 'Piqueos y entradas para compartir', 1),
('Salsas', 'Salsas y cremas adicionales', 1);

INSERT INTO tipo_producto (nombre, descripcion, estado) VALUES
('Plato principal', 'Producto principal de la carta', 1),
('Combo', 'Producto compuesto por varios elementos', 1),
('Complemento', 'Acompañamiento o guarnición', 1),
('Bebida', 'Producto líquido para consumo', 1),
('Adicional', 'Producto adicional de bajo costo', 1);

INSERT INTO tipo_documento (nombre, abreviatura, estado) VALUES
('Documento Nacional de Identidad', 'DNI', 1),
('Registro Único de Contribuyentes', 'RUC', 1),
('Carnet de Extranjería', 'CE', 1);

INSERT INTO rol (nombre, descripcion, estado) VALUES
('Administrador', 'Acceso total al sistema', 1),
('Cajero', 'Registro de ventas y pagos', 1),
('Mozo', 'Atención de mesas y pedidos', 1),
('Supervisor', 'Supervisión operativa del local', 1);

INSERT INTO distrito (nombre, estado) VALUES
('Magdalena del Mar', 1),
('San Isidro', 1),
('Pueblo Libre', 1),
('Jesús María', 1),
('Miraflores', 1),
('San Miguel', 1);

INSERT INTO medio_pago (nombre, descripcion, estado) VALUES
('Efectivo', 'Pago en caja con dinero en efectivo', 1),
('Tarjeta', 'Pago con tarjeta de débito o crédito', 1),
('Yape', 'Pago mediante billetera Yape', 1),
('Plin', 'Pago mediante billetera Plin', 1),
('Transferencia', 'Pago mediante transferencia bancaria', 1);

INSERT INTO estado_venta (nombre, descripcion, estado) VALUES
('Registrada', 'Venta registrada en el sistema', 1),
('Pagada', 'Venta pagada por el cliente', 1),
('Anulada', 'Venta anulada por error o solicitud', 1),
('Entregada', 'Pedido entregado al cliente', 1);

INSERT INTO estado_reserva (nombre, descripcion, estado) VALUES
('Pendiente', 'Reserva registrada pendiente de confirmación', 1),
('Confirmada', 'Reserva confirmada por el local', 1),
('Atendida', 'Reserva atendida en el local', 1),
('Cancelada', 'Reserva cancelada por el cliente o local', 1);

INSERT INTO tipo_venta (nombre, descripcion, estado) VALUES
('Salón', 'Consumo dentro del local', 1),
('Para llevar', 'Pedido recogido por el cliente', 1),
('Delivery', 'Pedido enviado al domicilio del cliente', 1);

INSERT INTO sucursal (nombre, direccion, telefono, estado, id_distrito) VALUES
('P''ollu Magdalena', 'Av. Del Ejército 1076 - 1078', '014001001', 1, 1);

INSERT INTO cliente (nombres, apellidos, numero_documento, telefono, correo, direccion, estado, id_tipo_documento, id_distrito) VALUES
('Carlos', 'Ramírez Soto', '45678912', '999111222', 'carlos.ramirez@mail.com', 'Av. Brasil 100', 1, 1, 1),
('María', 'Torres Díaz', '40876543', '999333444', 'maria.torres@mail.com', 'Jr. Castilla 250', 1, 1, 3),
('Empresa Eventos Lima', 'S.A.C.', '20604567891', '999555666', 'compras@eventoslima.pe', 'Av. Javier Prado 500', 1, 2, 2);

-- Nota: Las contraseñas son referenciales para pruebas académicas.
-- En una aplicación real deben almacenarse con hash BCrypt.
INSERT INTO usuario (nombres, apellidos, username, password, correo, estado, id_rol, id_sucursal) VALUES
('Administrador', 'General', 'admin', 'admin123', 'admin@pollu.pe', 1, 1, 1),
('Lucía', 'Fernández', 'cajero1', 'caja123', 'lucia.fernandez@pollu.pe', 1, 2, 1),
('Pedro', 'Salazar', 'mozo1', 'mozo123', 'pedro.salazar@pollu.pe', 1, 3, 1),
('Rosa', 'Paredes', 'supervisor1', 'super123', 'rosa.paredes@pollu.pe', 1, 4, 1);

INSERT INTO mesa (numero, capacidad, estado, id_sucursal) VALUES
('M01', 2, 1, 1),
('M02', 4, 1, 1),
('M03', 4, 1, 1),
('M04', 6, 1, 1),
('M05', 8, 1, 1);

INSERT INTO producto (codigo, nombre, descripcion, precio_venta, estado, id_categoria, id_tipo_producto) VALUES
('POL-001', '1 Pollo a la Brasa', 'Pollo entero con papas y ensalada', 69.90, 1, 1, 1),
('POL-002', '1/2 Pollo a la Brasa', 'Medio pollo con papas y ensalada', 39.90, 1, 1, 1),
('POL-003', '1/4 Pollo a la Brasa', 'Cuarto de pollo con papas y ensalada', 24.90, 1, 1, 1),
('COM-001', 'Combo Familiar', 'Un pollo, papas, ensalada y gaseosa familiar', 84.90, 1, 2, 2),
('COM-002', 'Combo Pareja', 'Medio pollo, papas, ensalada y dos bebidas', 49.90, 1, 2, 2),
('GUA-001', 'Papas Fritas Familiares', 'Porción familiar de papas fritas', 18.00, 1, 3, 3),
('GUA-002', 'Ensalada Fresca', 'Ensalada de verduras frescas', 12.00, 1, 3, 3),
('BEB-001', 'Gaseosa Familiar', 'Gaseosa de 1.5 litros', 12.00, 1, 4, 4),
('BEB-002', 'Chicha Morada', 'Chicha morada personal', 8.00, 1, 4, 4),
('SAL-001', 'Ají de la casa', 'Porción adicional de ají', 2.00, 1, 6, 5);

INSERT INTO inventario_producto (stock_actual, stock_minimo, fecha_actualizacion, estado, id_producto, id_sucursal) VALUES
(30, 5, NOW(), 1, 1, 1),
(25, 5, NOW(), 1, 2, 1),
(40, 8, NOW(), 1, 3, 1),
(20, 5, NOW(), 1, 4, 1),
(20, 5, NOW(), 1, 5, 1),
(50, 10, NOW(), 1, 6, 1),
(40, 10, NOW(), 1, 7, 1),
(60, 10, NOW(), 1, 8, 1),
(60, 10, NOW(), 1, 9, 1),
(100, 20, NOW(), 1, 10, 1);

INSERT INTO reserva (fecha_reserva, hora_reserva, cantidad_personas, observacion, estado, id_cliente, id_mesa, id_estado_reserva) VALUES
('2026-06-24', '19:30:00', 4, 'Reserva familiar cerca a ventana', 1, 1, 2, 2),
('2026-06-25', '20:00:00', 6, 'Celebración de cumpleaños', 1, 2, 4, 1);

INSERT INTO venta (fecha_venta, subtotal, igv, total, observacion, id_cliente, id_usuario, id_sucursal, id_tipo_venta, id_estado_venta, id_medio_pago) VALUES
('2026-06-20 13:30:00', 69.90, 12.58, 82.48, 'Venta en salón', 1, 2, 1, 1, 2, 1),
('2026-06-20 20:15:00', 96.90, 17.44, 114.34, 'Pedido para llevar', 2, 2, 1, 2, 2, 3),
('2026-06-21 21:00:00', 84.90, 15.28, 100.18, 'Combo familiar', 3, 2, 1, 3, 1, 2);

INSERT INTO detalle_venta (cantidad, precio_unitario, descuento, subtotal, id_venta, id_producto) VALUES
(1, 69.90, 0.00, 69.90, 1, 1),
(1, 84.90, 0.00, 84.90, 2, 4),
(1, 12.00, 0.00, 12.00, 2, 8),
(1, 84.90, 0.00, 84.90, 3, 4);

INSERT INTO comprobante (tipo_comprobante, serie, numero, fecha_emision, total, id_venta) VALUES
('BOLETA', 'B001', '00000001', '2026-06-20 13:31:00', 82.48, 1),
('BOLETA', 'B001', '00000002', '2026-06-20 20:16:00', 114.34, 2),
('FACTURA', 'F001', '00000001', '2026-06-21 21:01:00', 100.18, 3);
