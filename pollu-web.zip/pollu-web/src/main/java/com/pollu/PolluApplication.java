package com.pollu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolluApplication {

    public static void main(String[] args) {
        SpringApplication.run(PolluApplication.class, args);
    }
}
