package com.pollu.config;

import com.pollu.entity.Rol;
import com.pollu.repository.RolRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class StringToRolConverter implements Converter<String, Rol> {

    private final RolRepository rolRepository;

    public StringToRolConverter(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    @Override
    public Rol convert(String source) {
        if (!StringUtils.hasText(source)) {
            return null;
        }
        return rolRepository.findById(Integer.valueOf(source)).orElse(null);
    }
}
