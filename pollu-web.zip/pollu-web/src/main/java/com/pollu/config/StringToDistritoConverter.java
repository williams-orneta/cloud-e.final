package com.pollu.config;

import com.pollu.entity.Distrito;
import com.pollu.repository.DistritoRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class StringToDistritoConverter implements Converter<String, Distrito> {

    private final DistritoRepository distritoRepository;

    public StringToDistritoConverter(DistritoRepository distritoRepository) {
        this.distritoRepository = distritoRepository;
    }

    @Override
    public Distrito convert(String source) {
        if (!StringUtils.hasText(source)) {
            return null;
        }
        return distritoRepository.findById(Integer.valueOf(source)).orElse(null);
    }
}
