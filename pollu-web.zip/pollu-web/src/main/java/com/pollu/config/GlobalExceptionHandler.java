package com.pollu.config;

import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(EntityNotFoundException.class)
    public Object manejarNoEncontrado(EntityNotFoundException ex,
                                       HttpServletRequest request,
                                       RedirectAttributes redirectAttributes) {
        return responder(ex.getMessage(), HttpStatus.NOT_FOUND, request, redirectAttributes);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public Object manejarIntegridadReferencial(DataIntegrityViolationException ex,
                                                HttpServletRequest request,
                                                RedirectAttributes redirectAttributes) {
        String mensaje = "No se puede eliminar este registro porque esta siendo utilizado por otro " +
                "(por ejemplo, un usuario asignado). Deshabilitalo en lugar de eliminarlo, o primero " +
                "reasigna/elimina los registros relacionados.";
        return responder(mensaje, HttpStatus.CONFLICT, request, redirectAttributes);
    }

    private Object responder(String mensaje, HttpStatus status,
                              HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String uri = request.getRequestURI();

        if (uri.startsWith("/api/")) {
            return ResponseEntity.status(status).body(mensaje);
        }

        redirectAttributes.addFlashAttribute("mensajeError", mensaje);
        if (uri.startsWith("/rol")) {
            return "redirect:/rol";
        } else if (uri.startsWith("/sucursal")) {
            return "redirect:/sucursal";
        } else if (uri.startsWith("/usuario")) {
            return "redirect:/usuario";
        }
        return "redirect:/";
    }
}