package com.pollu.config;

import com.pollu.entity.Sucursal;
import com.pollu.repository.SucursalRepository;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class StringToSucursalConverter implements Converter<String, Sucursal> {

    private final SucursalRepository sucursalRepository;

    public StringToSucursalConverter(SucursalRepository sucursalRepository) {
        this.sucursalRepository = sucursalRepository;
    }

    @Override
    public Sucursal convert(String source) {
        if (!StringUtils.hasText(source)) {
            return null;
        }
        return sucursalRepository.findById(Integer.valueOf(source)).orElse(null);
    }
}
