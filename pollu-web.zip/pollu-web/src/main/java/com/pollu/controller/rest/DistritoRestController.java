package com.pollu.controller.rest;

import com.pollu.entity.Distrito;
import com.pollu.service.DistritoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/distritos")
public class DistritoRestController {

    private final DistritoService distritoService;

    public DistritoRestController(DistritoService distritoService) {
        this.distritoService = distritoService;
    }

    @GetMapping
    public ResponseEntity<List<Distrito>> listar() {
        return ResponseEntity.ok(distritoService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<Distrito>> listarActivos() {
        return ResponseEntity.ok(distritoService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Distrito> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(distritoService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<Distrito> registrar(@Valid @RequestBody Distrito distrito) {
        Distrito creado = distritoService.registrar(distrito);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Distrito> actualizar(@PathVariable Integer id, @Valid @RequestBody Distrito distrito) {
        return ResponseEntity.ok(distritoService.actualizar(id, distrito));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        distritoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        distritoService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        distritoService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}