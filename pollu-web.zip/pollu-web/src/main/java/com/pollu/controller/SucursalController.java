package com.pollu.controller;

import com.pollu.entity.Sucursal;
import com.pollu.repository.DistritoRepository;
import com.pollu.service.SucursalService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/sucursal")
public class SucursalController {

    private final SucursalService sucursalService;
    private final DistritoRepository distritoRepository;

    public SucursalController(SucursalService sucursalService, DistritoRepository distritoRepository) {
        this.sucursalService = sucursalService;
        this.distritoRepository = distritoRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("sucursales", sucursalService.listarTodos());
        return "sucursal/listarsucursal";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("sucursal", new Sucursal());
        model.addAttribute("distritos", distritoRepository.findByEstadoTrue());
        return "sucursal/accionessucursal";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("sucursal", sucursalService.buscarPorId(id));
        model.addAttribute("distritos", distritoRepository.findByEstadoTrue());
        return "sucursal/accionessucursal";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("sucursal") Sucursal sucursal,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("distritos", distritoRepository.findByEstadoTrue());
            return "sucursal/accionessucursal";
        }
        if (sucursal.getIdSucursal() == null) {
            sucursalService.registrar(sucursal);
            redirectAttributes.addFlashAttribute("mensaje", "Sucursal registrada correctamente.");
        } else {
            sucursalService.actualizar(sucursal.getIdSucursal(), sucursal);
            redirectAttributes.addFlashAttribute("mensaje", "Sucursal actualizada correctamente.");
        }
        return "redirect:/sucursal";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        sucursalService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Sucursal eliminada correctamente.");
        return "redirect:/sucursal";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        sucursalService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Sucursal habilitada correctamente.");
        return "redirect:/sucursal";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        sucursalService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Sucursal deshabilitada correctamente.");
        return "redirect:/sucursal";
    }
}
