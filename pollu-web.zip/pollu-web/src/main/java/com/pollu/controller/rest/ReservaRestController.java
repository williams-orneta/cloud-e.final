package com.pollu.controller.rest;

import com.pollu.entity.ReservaEntity;
import com.pollu.service.ReservaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservas")
public class ReservaRestController {

    private final ReservaService reservaService;

    public ReservaRestController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @GetMapping
    public ResponseEntity<List<ReservaEntity>> listar() {
        return ResponseEntity.ok(reservaService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<ReservaEntity>> listarActivos() {
        return ResponseEntity.ok(reservaService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaEntity> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(reservaService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<ReservaEntity> registrar(@Valid @RequestBody ReservaEntity reserva) {
        ReservaEntity creado = reservaService.registrar(reserva);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReservaEntity> actualizar(@PathVariable Integer id, @Valid @RequestBody ReservaEntity reserva) {
        return ResponseEntity.ok(reservaService.actualizar(id, reserva));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        reservaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        reservaService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        reservaService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}