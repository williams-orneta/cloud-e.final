package com.pollu.controller;

import com.pollu.entity.Rol;
import com.pollu.service.RolService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/rol")
public class RolController {

    private final RolService rolService;

    public RolController(RolService rolService) {
        this.rolService = rolService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("roles", rolService.listarTodos());
        return "rol/listarrol";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("rol", new Rol());
        return "rol/accionesrol";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("rol", rolService.buscarPorId(id));
        return "rol/accionesrol";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("rol") Rol rol,
                           BindingResult result,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "rol/accionesrol";
        }
        if (rol.getIdRol() == null) {
            rolService.registrar(rol);
            redirectAttributes.addFlashAttribute("mensaje", "Rol registrado correctamente.");
        } else {
            rolService.actualizar(rol.getIdRol(), rol);
            redirectAttributes.addFlashAttribute("mensaje", "Rol actualizado correctamente.");
        }
        return "redirect:/rol";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        rolService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Rol eliminado correctamente.");
        return "redirect:/rol";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        rolService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Rol habilitado correctamente.");
        return "redirect:/rol";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        rolService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Rol deshabilitado correctamente.");
        return "redirect:/rol";
    }
}
