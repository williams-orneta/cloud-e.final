package com.pollu.controller.rest;

import com.pollu.entity.MesaEntity;
import com.pollu.service.MesaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mesas")
public class MesaRestController {

    private final MesaService mesaService;

    public MesaRestController(MesaService mesaService) {
        this.mesaService = mesaService;
    }

    @GetMapping
    public ResponseEntity<List<MesaEntity>> listar() {
        return ResponseEntity.ok(mesaService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<MesaEntity>> listarActivos() {
        return ResponseEntity.ok(mesaService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MesaEntity> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(mesaService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<MesaEntity> registrar(@Valid @RequestBody MesaEntity mesa) {
        MesaEntity creado = mesaService.registrar(mesa);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MesaEntity> actualizar(@PathVariable Integer id, @Valid @RequestBody MesaEntity mesa) {
        return ResponseEntity.ok(mesaService.actualizar(id, mesa));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        mesaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        mesaService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        mesaService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}