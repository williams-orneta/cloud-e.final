package com.pollu.controller;

import com.pollu.entity.EstadoReservaEntity;
import com.pollu.service.EstadoReservaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/estado-reserva")
public class EstadoReservaController {

    private final EstadoReservaService estadoReservaService;

    public EstadoReservaController(EstadoReservaService estadoReservaService) {
        this.estadoReservaService = estadoReservaService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("estadosReserva", estadoReservaService.listarTodos());
        return "estadoreserva/listarestadoreserva";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("estadoReserva", new EstadoReservaEntity());
        return "estadoreserva/accionesestadoreserva";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        EstadoReservaEntity estadoReserva = estadoReservaService.buscarPorId(id);
        model.addAttribute("estadoReserva", estadoReserva);
        return "estadoreserva/accionesestadoreserva";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("estadoReserva") EstadoReservaEntity estadoReserva,
                           BindingResult result,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "estadoreserva/accionesestadoreserva";
        }
        boolean esNuevo = estadoReserva.getIdEstadoReserva() == null;
        if (esNuevo) {
            estadoReservaService.registrar(estadoReserva);
            redirectAttributes.addFlashAttribute("mensaje", "Estado de reserva registrado correctamente.");
        } else {
            estadoReservaService.actualizar(estadoReserva.getIdEstadoReserva(), estadoReserva);
            redirectAttributes.addFlashAttribute("mensaje", "Estado de reserva actualizado correctamente.");
        }
        return "redirect:/estado-reserva";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        estadoReservaService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Estado de reserva eliminado correctamente.");
        return "redirect:/estado-reserva";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        estadoReservaService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Estado de reserva habilitado correctamente.");
        return "redirect:/estado-reserva";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        estadoReservaService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Estado de reserva deshabilitado correctamente.");
        return "redirect:/estado-reserva";
    }
}