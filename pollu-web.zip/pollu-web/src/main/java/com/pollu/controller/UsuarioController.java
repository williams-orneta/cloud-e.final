package com.pollu.controller;

import com.pollu.entity.Usuario;
import com.pollu.repository.RolRepository;
import com.pollu.repository.SucursalRepository;
import com.pollu.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/usuario")
public class UsuarioController {

    private final UsuarioService usuarioService;
    private final RolRepository rolRepository;
    private final SucursalRepository sucursalRepository;

    public UsuarioController(UsuarioService usuarioService,
                              RolRepository rolRepository,
                              SucursalRepository sucursalRepository) {
        this.usuarioService = usuarioService;
        this.rolRepository = rolRepository;
        this.sucursalRepository = sucursalRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("usuarios", usuarioService.listarTodos());
        return "usuario/listarusuario";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("usuario", new Usuario());
        cargarCombos(model);
        return "usuario/accionesusuario";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        Usuario usuario = usuarioService.buscarPorId(id);
        usuario.setPassword("");
        model.addAttribute("usuario", usuario);
        cargarCombos(model);
        return "usuario/accionesusuario";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("usuario") Usuario usuario,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        boolean esNuevo = usuario.getIdUsuario() == null;
        if (esNuevo && (usuario.getPassword() == null || usuario.getPassword().isBlank())) {
            result.rejectValue("password", "NotBlank", "La contrasena es obligatoria");
        }

        if (result.hasErrors()) {
            cargarCombos(model);
            return "usuario/accionesusuario";
        }

        if (esNuevo) {
            usuarioService.registrar(usuario);
            redirectAttributes.addFlashAttribute("mensaje", "Usuario registrado correctamente.");
        } else {
            usuarioService.actualizar(usuario.getIdUsuario(), usuario);
            redirectAttributes.addFlashAttribute("mensaje", "Usuario actualizado correctamente.");
        }
        return "redirect:/usuario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        usuarioService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Usuario eliminado correctamente.");
        return "redirect:/usuario";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        usuarioService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Usuario habilitado correctamente.");
        return "redirect:/usuario";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        usuarioService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Usuario deshabilitado correctamente.");
        return "redirect:/usuario";
    }

    private void cargarCombos(Model model) {
        model.addAttribute("roles", rolRepository.findByEstadoTrue());
        model.addAttribute("sucursales", sucursalRepository.findByEstadoTrue());
    }
}
