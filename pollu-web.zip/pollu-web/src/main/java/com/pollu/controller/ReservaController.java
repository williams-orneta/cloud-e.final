package com.pollu.controller;

import com.pollu.entity.ReservaEntity;
import com.pollu.repository.ClienteRepository;
import com.pollu.repository.EstadoReservaRepository;
import com.pollu.repository.MesaRepository;
import com.pollu.service.ReservaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/reserva")
public class ReservaController {

    private final ReservaService reservaService;
    private final ClienteRepository clienteRepository;
    private final MesaRepository mesaRepository;
    private final EstadoReservaRepository estadoReservaRepository;

    public ReservaController(ReservaService reservaService,
                              ClienteRepository clienteRepository,
                              MesaRepository mesaRepository,
                              EstadoReservaRepository estadoReservaRepository) {
        this.reservaService = reservaService;
        this.clienteRepository = clienteRepository;
        this.mesaRepository = mesaRepository;
        this.estadoReservaRepository = estadoReservaRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("reservas", reservaService.listarTodos());
        return "reserva/listarreserva";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("reserva", new ReservaEntity());
        cargarCombos(model);
        return "reserva/accionesreserva";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        ReservaEntity reserva = reservaService.buscarPorId(id);
        model.addAttribute("reserva", reserva);
        cargarCombos(model);
        return "reserva/accionesreserva";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("reserva") ReservaEntity reserva,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            cargarCombos(model);
            return "reserva/accionesreserva";
        }
        boolean esNuevo = reserva.getIdReserva() == null;
        if (esNuevo) {
            reservaService.registrar(reserva);
            redirectAttributes.addFlashAttribute("mensaje", "Reserva registrada correctamente.");
        } else {
            reservaService.actualizar(reserva.getIdReserva(), reserva);
            redirectAttributes.addFlashAttribute("mensaje", "Reserva actualizada correctamente.");
        }
        return "redirect:/reserva";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        reservaService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Reserva eliminada correctamente.");
        return "redirect:/reserva";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        reservaService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Reserva habilitada correctamente.");
        return "redirect:/reserva";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        reservaService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Reserva deshabilitada correctamente.");
        return "redirect:/reserva";
    }

    private void cargarCombos(Model model) {
        model.addAttribute("clientes", clienteRepository.findByEstadoTrue());
        model.addAttribute("mesas", mesaRepository.findByEstadoTrue());
        model.addAttribute("estadosReserva", estadoReservaRepository.findByEstadoTrue());
    }
}