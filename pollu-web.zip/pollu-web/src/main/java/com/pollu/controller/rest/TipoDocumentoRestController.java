package com.pollu.controller.rest;

import com.pollu.entity.TipoDocumentoEntity;
import com.pollu.service.TipoDocumentoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tipos-documento")
public class TipoDocumentoRestController {

    private final TipoDocumentoService tipoDocumentoService;

    public TipoDocumentoRestController(TipoDocumentoService tipoDocumentoService) {
        this.tipoDocumentoService = tipoDocumentoService;
    }

    @GetMapping
    public ResponseEntity<List<TipoDocumentoEntity>> listar() {
        return ResponseEntity.ok(tipoDocumentoService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<TipoDocumentoEntity>> listarActivos() {
        return ResponseEntity.ok(tipoDocumentoService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoDocumentoEntity> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(tipoDocumentoService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<TipoDocumentoEntity> registrar(@Valid @RequestBody TipoDocumentoEntity tipoDocumento) {
    	TipoDocumentoEntity creado = tipoDocumentoService.registrar(tipoDocumento);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TipoDocumentoEntity> actualizar(@PathVariable Integer id, @Valid @RequestBody TipoDocumentoEntity tipoDocumento) {
        return ResponseEntity.ok(tipoDocumentoService.actualizar(id, tipoDocumento));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        tipoDocumentoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        tipoDocumentoService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        tipoDocumentoService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}