package com.pollu.controller;

import com.pollu.entity.Distrito;
import com.pollu.service.DistritoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/distrito")
public class DistritoController {

    private final DistritoService distritoService;

    public DistritoController(DistritoService distritoService) {
        this.distritoService = distritoService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("distritos", distritoService.listarTodos());
        return "distrito/listardistrito";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("distrito", new Distrito());
        return "distrito/accionesdistrito";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        Distrito distrito = distritoService.buscarPorId(id);
        model.addAttribute("distrito", distrito);
        return "distrito/accionesdistrito";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("distrito") Distrito distrito,
                           BindingResult result,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "distrito/accionesdistrito";
        }
        boolean esNuevo = distrito.getIdDistrito() == null;
        if (esNuevo) {
            distritoService.registrar(distrito);
            redirectAttributes.addFlashAttribute("mensaje", "Distrito registrado correctamente.");
        } else {
            distritoService.actualizar(distrito.getIdDistrito(), distrito);
            redirectAttributes.addFlashAttribute("mensaje", "Distrito actualizado correctamente.");
        }
        return "redirect:/distrito";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        distritoService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Distrito eliminado correctamente.");
        return "redirect:/distrito";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        distritoService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Distrito habilitado correctamente.");
        return "redirect:/distrito";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        distritoService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Distrito deshabilitado correctamente.");
        return "redirect:/distrito";
    }
}