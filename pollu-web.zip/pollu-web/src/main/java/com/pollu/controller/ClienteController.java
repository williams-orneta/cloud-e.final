package com.pollu.controller;

import com.pollu.entity.ClienteEntity;
import com.pollu.repository.DistritoRepository;
import com.pollu.repository.TipoDocumentoRepository;
import com.pollu.service.ClienteService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    private final ClienteService clienteService;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final DistritoRepository distritoRepository;

    public ClienteController(ClienteService clienteService,
                              TipoDocumentoRepository tipoDocumentoRepository,
                              DistritoRepository distritoRepository) {
        this.clienteService = clienteService;
        this.tipoDocumentoRepository = tipoDocumentoRepository;
        this.distritoRepository = distritoRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("clientes", clienteService.listarTodos());
        return "cliente/listarcliente";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("cliente", new ClienteEntity());
        cargarCombos(model);
        return "cliente/accionescliente";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        ClienteEntity cliente = clienteService.buscarPorId(id);
        model.addAttribute("cliente", cliente);
        cargarCombos(model);
        return "cliente/accionescliente";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("cliente") ClienteEntity cliente,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            cargarCombos(model);
            return "cliente/accionescliente";
        }
        boolean esNuevo = cliente.getIdCliente() == null;
        if (esNuevo) {
            clienteService.registrar(cliente);
            redirectAttributes.addFlashAttribute("mensaje", "Cliente registrado correctamente.");
        } else {
            clienteService.actualizar(cliente.getIdCliente(), cliente);
            redirectAttributes.addFlashAttribute("mensaje", "Cliente actualizado correctamente.");
        }
        return "redirect:/cliente";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        clienteService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Cliente eliminado correctamente.");
        return "redirect:/cliente";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        clienteService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Cliente habilitado correctamente.");
        return "redirect:/cliente";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        clienteService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Cliente deshabilitado correctamente.");
        return "redirect:/cliente";
    }

    private void cargarCombos(Model model) {
        model.addAttribute("tiposDocumento", tipoDocumentoRepository.findByEstadoTrue());
        model.addAttribute("distritos", distritoRepository.findByEstadoTrue());
    }
}