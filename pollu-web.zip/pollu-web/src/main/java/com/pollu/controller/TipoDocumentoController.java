package com.pollu.controller;

import com.pollu.entity.TipoDocumentoEntity;
import com.pollu.service.TipoDocumentoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/tipo-documento")
public class TipoDocumentoController {

    private final TipoDocumentoService tipoDocumentoService;

    public TipoDocumentoController(TipoDocumentoService tipoDocumentoService) {
        this.tipoDocumentoService = tipoDocumentoService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("tiposDocumento", tipoDocumentoService.listarTodos());
        return "tipodocumento/listartipodocumento";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("tipoDocumento", new TipoDocumentoEntity());
        return "tipodocumento/accionestipodocumento";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        TipoDocumentoEntity tipoDocumento = tipoDocumentoService.buscarPorId(id);
        model.addAttribute("tipoDocumento", tipoDocumento);
        return "tipodocumento/accionestipodocumento";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("tipoDocumento") TipoDocumentoEntity tipoDocumento,
                           BindingResult result,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "tipodocumento/accionestipodocumento";
        }
        boolean esNuevo = tipoDocumento.getIdTipoDocumento() == null;
        if (esNuevo) {
            tipoDocumentoService.registrar(tipoDocumento);
            redirectAttributes.addFlashAttribute("mensaje", "Tipo de documento registrado correctamente.");
        } else {
            tipoDocumentoService.actualizar(tipoDocumento.getIdTipoDocumento(), tipoDocumento);
            redirectAttributes.addFlashAttribute("mensaje", "Tipo de documento actualizado correctamente.");
        }
        return "redirect:/tipo-documento";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        tipoDocumentoService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Tipo de documento eliminado correctamente.");
        return "redirect:/tipo-documento";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        tipoDocumentoService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Tipo de documento habilitado correctamente.");
        return "redirect:/tipo-documento";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        tipoDocumentoService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Tipo de documento deshabilitado correctamente.");
        return "redirect:/tipo-documento";
    }
}