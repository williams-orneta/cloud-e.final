package com.pollu.controller.rest;

import com.pollu.entity.EstadoReservaEntity;
import com.pollu.service.EstadoReservaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estados-reserva")
public class EstadoReservaRestController {

    private final EstadoReservaService estadoReservaService;

    public EstadoReservaRestController(EstadoReservaService estadoReservaService) {
        this.estadoReservaService = estadoReservaService;
    }

    @GetMapping
    public ResponseEntity<List<EstadoReservaEntity>> listar() {
        return ResponseEntity.ok(estadoReservaService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<EstadoReservaEntity>> listarActivos() {
        return ResponseEntity.ok(estadoReservaService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstadoReservaEntity> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(estadoReservaService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<EstadoReservaEntity> registrar(@Valid @RequestBody EstadoReservaEntity estadoReserva) {
        EstadoReservaEntity creado = estadoReservaService.registrar(estadoReserva);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstadoReservaEntity> actualizar(@PathVariable Integer id, @Valid @RequestBody EstadoReservaEntity estadoReserva) {
        return ResponseEntity.ok(estadoReservaService.actualizar(id, estadoReserva));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        estadoReservaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        estadoReservaService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        estadoReservaService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}