package com.pollu.controller.rest;

import com.pollu.entity.Sucursal;
import com.pollu.service.SucursalService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sucursales")
public class SucursalRestController {

    private final SucursalService sucursalService;

    public SucursalRestController(SucursalService sucursalService) {
        this.sucursalService = sucursalService;
    }

    @GetMapping
    public ResponseEntity<List<Sucursal>> listar() {
        return ResponseEntity.ok(sucursalService.listarTodos());
    }

    @GetMapping("/activos")
    public ResponseEntity<List<Sucursal>> listarActivos() {
        return ResponseEntity.ok(sucursalService.listarActivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sucursal> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(sucursalService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<Sucursal> registrar(@Valid @RequestBody Sucursal sucursal) {
        Sucursal creada = sucursalService.registrar(sucursal);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sucursal> actualizar(@PathVariable Integer id, @Valid @RequestBody Sucursal sucursal) {
        return ResponseEntity.ok(sucursalService.actualizar(id, sucursal));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        sucursalService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/habilitar")
    public ResponseEntity<Void> habilitar(@PathVariable Integer id) {
        sucursalService.habilitar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/deshabilitar")
    public ResponseEntity<Void> deshabilitar(@PathVariable Integer id) {
        sucursalService.deshabilitar(id);
        return ResponseEntity.noContent().build();
    }
}
