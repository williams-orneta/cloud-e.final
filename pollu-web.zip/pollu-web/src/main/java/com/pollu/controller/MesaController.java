package com.pollu.controller;

import com.pollu.entity.MesaEntity;
import com.pollu.repository.SucursalRepository;
import com.pollu.service.MesaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mesa")
public class MesaController {

    private final MesaService mesaService;
    private final SucursalRepository sucursalRepository;

    public MesaController(MesaService mesaService, SucursalRepository sucursalRepository) {
        this.mesaService = mesaService;
        this.sucursalRepository = sucursalRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("mesas", mesaService.listarTodos());
        return "mesa/listarmesa";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("mesa", new MesaEntity());
        cargarCombos(model);
        return "mesa/accionesmesa";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        MesaEntity mesa = mesaService.buscarPorId(id);
        model.addAttribute("mesa", mesa);
        cargarCombos(model);
        return "mesa/accionesmesa";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("mesa") MesaEntity mesa,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            cargarCombos(model);
            return "mesa/accionesmesa";
        }
        boolean esNuevo = mesa.getIdMesa() == null;
        if (esNuevo) {
            mesaService.registrar(mesa);
            redirectAttributes.addFlashAttribute("mensaje", "Mesa registrada correctamente.");
        } else {
            mesaService.actualizar(mesa.getIdMesa(), mesa);
            redirectAttributes.addFlashAttribute("mensaje", "Mesa actualizada correctamente.");
        }
        return "redirect:/mesa";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        mesaService.eliminar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Mesa eliminada correctamente.");
        return "redirect:/mesa";
    }

    @GetMapping("/habilitar/{id}")
    public String habilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        mesaService.habilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Mesa habilitada correctamente.");
        return "redirect:/mesa";
    }

    @GetMapping("/deshabilitar/{id}")
    public String deshabilitar(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        mesaService.deshabilitar(id);
        redirectAttributes.addFlashAttribute("mensaje", "Mesa deshabilitada correctamente.");
        return "redirect:/mesa";
    }

    private void cargarCombos(Model model) {
        model.addAttribute("sucursales", sucursalRepository.findByEstadoTrue());
    }
}