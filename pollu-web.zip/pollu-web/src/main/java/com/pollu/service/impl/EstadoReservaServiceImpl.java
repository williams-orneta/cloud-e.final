package com.pollu.service.impl;

import com.pollu.entity.EstadoReservaEntity;
import com.pollu.repository.EstadoReservaRepository;
import com.pollu.service.EstadoReservaService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EstadoReservaServiceImpl implements EstadoReservaService {

    private final EstadoReservaRepository estadoReservaRepository;

    public EstadoReservaServiceImpl(EstadoReservaRepository estadoReservaRepository) {
        this.estadoReservaRepository = estadoReservaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadoReservaEntity> listarTodos() {
        return estadoReservaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadoReservaEntity> listarActivos() {
        return estadoReservaRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public EstadoReservaEntity buscarPorId(Integer id) {
        return estadoReservaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el estado de reserva con id " + id));
    }

    @Override
    public EstadoReservaEntity registrar(EstadoReservaEntity estadoReserva) {
        estadoReserva.setIdEstadoReserva(null);
        estadoReserva.setEstado(Boolean.TRUE);
        return estadoReservaRepository.save(estadoReserva);
    }

    @Override
    public EstadoReservaEntity actualizar(Integer id, EstadoReservaEntity estadoReserva) {
        EstadoReservaEntity existente = buscarPorId(id);
        existente.setNombre(estadoReserva.getNombre());
        existente.setDescripcion(estadoReserva.getDescripcion());
        return estadoReservaRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        EstadoReservaEntity existente = buscarPorId(id);
        estadoReservaRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        EstadoReservaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        estadoReservaRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        EstadoReservaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        estadoReservaRepository.save(existente);
    }
}