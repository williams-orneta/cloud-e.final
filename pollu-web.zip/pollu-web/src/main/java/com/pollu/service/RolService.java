package com.pollu.service;

import com.pollu.entity.Rol;

import java.util.List;

public interface RolService {

    List<Rol> listarTodos();

    List<Rol> listarActivos();

    Rol buscarPorId(Integer id);

    Rol registrar(Rol rol);

    Rol actualizar(Integer id, Rol rol);

    void eliminar(Integer id);

    void habilitar(Integer id);

    void deshabilitar(Integer id);
}
