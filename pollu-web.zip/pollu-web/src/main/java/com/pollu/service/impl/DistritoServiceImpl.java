package com.pollu.service.impl;

import com.pollu.entity.Distrito;
import com.pollu.repository.DistritoRepository;
import com.pollu.service.DistritoService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DistritoServiceImpl implements DistritoService {

    private final DistritoRepository distritoRepository;

    public DistritoServiceImpl(DistritoRepository distritoRepository) {
        this.distritoRepository = distritoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Distrito> listarTodos() {
        return distritoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Distrito> listarActivos() {
        return distritoRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public Distrito buscarPorId(Integer id) {
        return distritoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el distrito con id " + id));
    }

    @Override
    public Distrito registrar(Distrito distrito) {
        distrito.setIdDistrito(null);
        distrito.setEstado(Boolean.TRUE);
        return distritoRepository.save(distrito);
    }

    @Override
    public Distrito actualizar(Integer id, Distrito distrito) {
        Distrito existente = buscarPorId(id);
        existente.setNombre(distrito.getNombre());
        return distritoRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        Distrito existente = buscarPorId(id);
        distritoRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        Distrito existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        distritoRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        Distrito existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        distritoRepository.save(existente);
    }
}