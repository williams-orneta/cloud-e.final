package com.pollu.service.impl;

import com.pollu.entity.Sucursal;
import com.pollu.repository.SucursalRepository;
import com.pollu.service.SucursalService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SucursalServiceImpl implements SucursalService {

    private final SucursalRepository sucursalRepository;

    public SucursalServiceImpl(SucursalRepository sucursalRepository) {
        this.sucursalRepository = sucursalRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Sucursal> listarTodos() {
        return sucursalRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Sucursal> listarActivos() {
        return sucursalRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public Sucursal buscarPorId(Integer id) {
        return sucursalRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la sucursal con id " + id));
    }

    @Override
    public Sucursal registrar(Sucursal sucursal) {
        sucursal.setIdSucursal(null);
        sucursal.setEstado(Boolean.TRUE);
        return sucursalRepository.save(sucursal);
    }

    @Override
    public Sucursal actualizar(Integer id, Sucursal sucursal) {
        Sucursal existente = buscarPorId(id);
        existente.setNombre(sucursal.getNombre());
        existente.setDireccion(sucursal.getDireccion());
        existente.setTelefono(sucursal.getTelefono());
        existente.setDistrito(sucursal.getDistrito());
        return sucursalRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        Sucursal existente = buscarPorId(id);
        sucursalRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        Sucursal existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        sucursalRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        Sucursal existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        sucursalRepository.save(existente);
    }
}
