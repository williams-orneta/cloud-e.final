package com.pollu.service.impl;

import com.pollu.entity.ClienteEntity;
import com.pollu.repository.ClienteRepository;
import com.pollu.service.ClienteService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteServiceImpl(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ClienteEntity> listarTodos() {
        return clienteRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ClienteEntity> listarActivos() {
        return clienteRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public ClienteEntity buscarPorId(Integer id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el cliente con id " + id));
    }

    @Override
    public ClienteEntity registrar(ClienteEntity cliente) {
        cliente.setIdCliente(null);
        cliente.setEstado(Boolean.TRUE);
        return clienteRepository.save(cliente);
    }

    @Override
    public ClienteEntity actualizar(Integer id, ClienteEntity cliente) {
        ClienteEntity existente = buscarPorId(id);
        existente.setNombres(cliente.getNombres());
        existente.setApellidos(cliente.getApellidos());
        existente.setNumeroDocumento(cliente.getNumeroDocumento());
        existente.setTelefono(cliente.getTelefono());
        existente.setCorreo(cliente.getCorreo());
        existente.setDireccion(cliente.getDireccion());
        existente.setIdTipoDocumento(cliente.getIdTipoDocumento());
        existente.setIdDistrito(cliente.getIdDistrito());
        return clienteRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        ClienteEntity existente = buscarPorId(id);
        clienteRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        ClienteEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        clienteRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        ClienteEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        clienteRepository.save(existente);
    }
}