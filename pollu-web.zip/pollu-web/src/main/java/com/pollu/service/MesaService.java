package com.pollu.service;

import com.pollu.entity.MesaEntity;
import java.util.List;

public interface MesaService {
    List<MesaEntity> listarTodos();
    List<MesaEntity> listarActivos();
    MesaEntity buscarPorId(Integer id);
    MesaEntity registrar(MesaEntity mesa);
    MesaEntity actualizar(Integer id, MesaEntity mesa);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}