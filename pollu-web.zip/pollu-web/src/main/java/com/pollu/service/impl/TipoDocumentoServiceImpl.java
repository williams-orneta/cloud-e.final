package com.pollu.service.impl;

import com.pollu.entity.TipoDocumentoEntity;
import com.pollu.repository.TipoDocumentoRepository;
import com.pollu.service.TipoDocumentoService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class TipoDocumentoServiceImpl implements TipoDocumentoService {

    private final TipoDocumentoRepository tipoDocumentoRepository;

    public TipoDocumentoServiceImpl(TipoDocumentoRepository tipoDocumentoRepository) {
        this.tipoDocumentoRepository = tipoDocumentoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TipoDocumentoEntity> listarTodos() {
        return tipoDocumentoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<TipoDocumentoEntity> listarActivos() {
        return tipoDocumentoRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public TipoDocumentoEntity buscarPorId(Integer id) {
        return tipoDocumentoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el tipo de documento con id " + id));
    }

    @Override
    public TipoDocumentoEntity registrar(TipoDocumentoEntity tipoDocumento) {
        tipoDocumento.setIdTipoDocumento(null);
        tipoDocumento.setEstado(Boolean.TRUE);
        return tipoDocumentoRepository.save(tipoDocumento);
    }

    @Override
    public TipoDocumentoEntity actualizar(Integer id, TipoDocumentoEntity tipoDocumento) {
        TipoDocumentoEntity existente = buscarPorId(id);
        existente.setNombre(tipoDocumento.getNombre());
        existente.setAbreviatura(tipoDocumento.getAbreviatura());
        return tipoDocumentoRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        TipoDocumentoEntity existente = buscarPorId(id);
        tipoDocumentoRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        TipoDocumentoEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        tipoDocumentoRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        TipoDocumentoEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        tipoDocumentoRepository.save(existente);
    }
}