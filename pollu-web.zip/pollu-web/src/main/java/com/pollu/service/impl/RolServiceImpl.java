package com.pollu.service.impl;

import com.pollu.entity.Rol;
import com.pollu.repository.RolRepository;
import com.pollu.service.RolService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RolServiceImpl implements RolService {

    private final RolRepository rolRepository;

    public RolServiceImpl(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Rol> listarTodos() {
        return rolRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Rol> listarActivos() {
        return rolRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public Rol buscarPorId(Integer id) {
        return rolRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el rol con id " + id));
    }

    @Override
    public Rol registrar(Rol rol) {
        rol.setIdRol(null);
        rol.setEstado(Boolean.TRUE);
        return rolRepository.save(rol);
    }

    @Override
    public Rol actualizar(Integer id, Rol rol) {
        Rol existente = buscarPorId(id);
        existente.setNombre(rol.getNombre());
        existente.setDescripcion(rol.getDescripcion());
        return rolRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        Rol existente = buscarPorId(id);
        rolRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        Rol existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        rolRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        Rol existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        rolRepository.save(existente);
    }
}
