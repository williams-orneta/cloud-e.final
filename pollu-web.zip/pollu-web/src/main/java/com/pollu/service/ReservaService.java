package com.pollu.service;

import com.pollu.entity.ReservaEntity;
import java.util.List;

public interface ReservaService {
    List<ReservaEntity> listarTodos();
    List<ReservaEntity> listarActivos();
    ReservaEntity buscarPorId(Integer id);
    ReservaEntity registrar(ReservaEntity reserva);
    ReservaEntity actualizar(Integer id, ReservaEntity reserva);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}