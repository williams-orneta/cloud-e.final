package com.pollu.service;

import com.pollu.entity.Distrito;
import java.util.List;

public interface DistritoService {
    List<Distrito> listarTodos();
    List<Distrito> listarActivos();
    Distrito buscarPorId(Integer id);
    Distrito registrar(Distrito distrito);
    Distrito actualizar(Integer id, Distrito distrito);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}