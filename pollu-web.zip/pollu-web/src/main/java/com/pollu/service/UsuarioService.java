package com.pollu.service;

import com.pollu.entity.Usuario;

import java.util.List;

public interface UsuarioService {

    List<Usuario> listarTodos();

    List<Usuario> listarActivos();

    Usuario buscarPorId(Integer id);

    Usuario registrar(Usuario usuario);

    Usuario actualizar(Integer id, Usuario usuario);

    void eliminar(Integer id);

    void habilitar(Integer id);

    void deshabilitar(Integer id);
}
