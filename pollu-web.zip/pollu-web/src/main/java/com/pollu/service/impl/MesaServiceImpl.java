package com.pollu.service.impl;

import com.pollu.entity.MesaEntity;
import com.pollu.repository.MesaRepository;
import com.pollu.service.MesaService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class MesaServiceImpl implements MesaService {

    private final MesaRepository mesaRepository;

    public MesaServiceImpl(MesaRepository mesaRepository) {
        this.mesaRepository = mesaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<MesaEntity> listarTodos() {
        return mesaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<MesaEntity> listarActivos() {
        return mesaRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public MesaEntity buscarPorId(Integer id) {
        return mesaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la mesa con id " + id));
    }

    @Override
    public MesaEntity registrar(MesaEntity mesa) {
        mesa.setIdMesa(null);
        mesa.setEstado(Boolean.TRUE);
        return mesaRepository.save(mesa);
    }

    @Override
    public MesaEntity actualizar(Integer id, MesaEntity mesa) {
        MesaEntity existente = buscarPorId(id);
        existente.setNumero(mesa.getNumero());
        existente.setCapacidad(mesa.getCapacidad());
        existente.setIdSucursal(mesa.getIdSucursal());
        return mesaRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        MesaEntity existente = buscarPorId(id);
        mesaRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        MesaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        mesaRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        MesaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        mesaRepository.save(existente);
    }
}