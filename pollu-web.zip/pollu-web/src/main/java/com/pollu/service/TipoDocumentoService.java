package com.pollu.service;

import com.pollu.entity.TipoDocumentoEntity;
import java.util.List;

public interface TipoDocumentoService {
    List<TipoDocumentoEntity> listarTodos();
    List<TipoDocumentoEntity> listarActivos();
    TipoDocumentoEntity buscarPorId(Integer id);
    TipoDocumentoEntity registrar(TipoDocumentoEntity tipoDocumento);
    TipoDocumentoEntity actualizar(Integer id, TipoDocumentoEntity tipoDocumento);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}