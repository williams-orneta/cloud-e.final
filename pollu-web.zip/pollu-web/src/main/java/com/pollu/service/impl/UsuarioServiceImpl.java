package com.pollu.service.impl;

import com.pollu.entity.Usuario;
import com.pollu.repository.UsuarioRepository;
import com.pollu.service.UsuarioService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@Transactional
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Usuario> listarActivos() {
        return usuarioRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public Usuario buscarPorId(Integer id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el usuario con id " + id));
    }

    @Override
    public Usuario registrar(Usuario usuario) {
        usuario.setIdUsuario(null);
        usuario.setEstado(Boolean.TRUE);
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        return usuarioRepository.save(usuario);
    }

    @Override
    public Usuario actualizar(Integer id, Usuario usuario) {
        Usuario existente = buscarPorId(id);
        existente.setNombres(usuario.getNombres());
        existente.setApellidos(usuario.getApellidos());
        existente.setUsername(usuario.getUsername());
        existente.setCorreo(usuario.getCorreo());
        existente.setRol(usuario.getRol());
        existente.setSucursal(usuario.getSucursal());

        if (StringUtils.hasText(usuario.getPassword())) {
            existente.setPassword(passwordEncoder.encode(usuario.getPassword()));
        }
        return usuarioRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        Usuario existente = buscarPorId(id);
        usuarioRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        Usuario existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        usuarioRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        Usuario existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        usuarioRepository.save(existente);
    }
}
