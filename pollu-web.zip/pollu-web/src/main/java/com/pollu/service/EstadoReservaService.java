package com.pollu.service;

import com.pollu.entity.EstadoReservaEntity;
import java.util.List;

public interface EstadoReservaService {
    List<EstadoReservaEntity> listarTodos();
    List<EstadoReservaEntity> listarActivos();
    EstadoReservaEntity buscarPorId(Integer id);
    EstadoReservaEntity registrar(EstadoReservaEntity estadoReserva);
    EstadoReservaEntity actualizar(Integer id, EstadoReservaEntity estadoReserva);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}