package com.pollu.service;

import com.pollu.entity.ClienteEntity;
import java.util.List;

public interface ClienteService {
    List<ClienteEntity> listarTodos();
    List<ClienteEntity> listarActivos();
    ClienteEntity buscarPorId(Integer id);
    ClienteEntity registrar(ClienteEntity cliente);
    ClienteEntity actualizar(Integer id, ClienteEntity cliente);
    void eliminar(Integer id);
    void habilitar(Integer id);
    void deshabilitar(Integer id);
}