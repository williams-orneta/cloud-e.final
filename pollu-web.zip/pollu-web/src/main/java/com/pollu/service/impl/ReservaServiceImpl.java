package com.pollu.service.impl;

import com.pollu.entity.ReservaEntity;
import com.pollu.repository.ReservaRepository;
import com.pollu.service.ReservaService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ReservaServiceImpl implements ReservaService {

    private final ReservaRepository reservaRepository;

    public ReservaServiceImpl(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReservaEntity> listarTodos() {
        return reservaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReservaEntity> listarActivos() {
        return reservaRepository.findByEstadoTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public ReservaEntity buscarPorId(Integer id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la reserva con id " + id));
    }

    @Override
    public ReservaEntity registrar(ReservaEntity reserva) {
        reserva.setIdReserva(null);
        reserva.setEstado(Boolean.TRUE);
        return reservaRepository.save(reserva);
    }

    @Override
    public ReservaEntity actualizar(Integer id, ReservaEntity reserva) {
        ReservaEntity existente = buscarPorId(id);
        existente.setFechaReserva(reserva.getFechaReserva());
        existente.setHoraReserva(reserva.getHoraReserva());
        existente.setCantidadPersonas(reserva.getCantidadPersonas());
        existente.setObservacion(reserva.getObservacion());
        existente.setIdCliente(reserva.getIdCliente());
        existente.setIdMesa(reserva.getIdMesa());
        existente.setIdEstadoReserva(reserva.getIdEstadoReserva());
        return reservaRepository.save(existente);
    }

    @Override
    public void eliminar(Integer id) {
        ReservaEntity existente = buscarPorId(id);
        reservaRepository.delete(existente);
    }

    @Override
    public void habilitar(Integer id) {
        ReservaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.TRUE);
        reservaRepository.save(existente);
    }

    @Override
    public void deshabilitar(Integer id) {
        ReservaEntity existente = buscarPorId(id);
        existente.setEstado(Boolean.FALSE);
        reservaRepository.save(existente);
    }
}