package com.pollu.service;

import com.pollu.entity.Sucursal;

import java.util.List;

public interface SucursalService {

    List<Sucursal> listarTodos();

    List<Sucursal> listarActivos();

    Sucursal buscarPorId(Integer id);

    Sucursal registrar(Sucursal sucursal);

    Sucursal actualizar(Integer id, Sucursal sucursal);

    void eliminar(Integer id);

    void habilitar(Integer id);

    void deshabilitar(Integer id);
}
