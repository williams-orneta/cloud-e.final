package com.pollu.repository;

import com.pollu.entity.ClienteEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<ClienteEntity, Integer> {
    java.util.List<ClienteEntity> findByEstadoTrue();
}