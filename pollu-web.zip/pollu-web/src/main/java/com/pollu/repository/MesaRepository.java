package com.pollu.repository;

import com.pollu.entity.MesaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MesaRepository extends JpaRepository<MesaEntity, Integer> {
    java.util.List<MesaEntity> findByEstadoTrue();
}