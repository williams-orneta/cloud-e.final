package com.pollu.repository;

import com.pollu.entity.TipoDocumentoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoDocumentoRepository extends JpaRepository<TipoDocumentoEntity, Integer> {
    java.util.List<TipoDocumentoEntity> findByEstadoTrue();
}