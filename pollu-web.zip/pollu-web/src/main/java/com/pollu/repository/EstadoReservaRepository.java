package com.pollu.repository;

import com.pollu.entity.EstadoReservaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstadoReservaRepository extends JpaRepository<EstadoReservaEntity, Integer> {
    java.util.List<EstadoReservaEntity> findByEstadoTrue();
}