package com.pollu.repository;

import com.pollu.entity.ReservaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<ReservaEntity, Integer> {
    java.util.List<ReservaEntity> findByEstadoTrue();
}