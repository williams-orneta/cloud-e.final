package com.pollu.repository;

import com.pollu.entity.Distrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistritoRepository extends JpaRepository<Distrito, Integer> {

    java.util.List<Distrito> findByEstadoTrue();
}
